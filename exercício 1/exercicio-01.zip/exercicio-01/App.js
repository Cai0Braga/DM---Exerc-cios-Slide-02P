import React, { useState } from 'react';
import { Text, TextInput, Button, Alert } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

export default function App() {
  const [nome, setNome] = useState('');

  return (
    <SafeAreaProvider>
      <SafeAreaView>
        
        <Text>Digite seu nome:</Text>

        <TextInput
          placeholder="Seu nome"
          value={nome}
          onChangeText={setNome}
        />

        <Button
          title="Mostrar Alerta"
          onPress={() => Alert.alert('Olá', nome)}
        />

      </SafeAreaView>
    </SafeAreaProvider>
  );
} 

//Thiago é o Caio da Turma B , eu infelizmente nao consegui fazer pelo VScode de jeito nenhum o unico jeito foi vazer por aqui usando o SafeAreaProvider// 