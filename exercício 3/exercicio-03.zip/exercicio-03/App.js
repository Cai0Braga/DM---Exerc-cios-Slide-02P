import React, { useState } from 'react';
import {Text, TextInput, Button, ScrollView} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

export default function App(){
const [itens, setItens] = useState([]);
const [texto, setTexto] = useState('');

 function adicionarItem() {
    setItens([...itens, texto]);
    setTexto('');
  }


  return(
<SafeAreaProvider>

     <SafeAreaView>
       <TextInput 
        placeholder="Digite aqui o nome dos seus Stands Favoritos"
        value={texto} 
        onChangeText={setTexto}
      />

      <Button
        title="Adicionar"
        onPress={adicionarItem}
      />
       
       
       
        <ScrollView>
          
           {itens.map((item, index) => (
          <Text key={index}style={{  fontSize: 100, marginVertical: 20 }}>{item}</Text > //coloquei este "Style" so para fazer o Scroll da tela ser ultilizado com maais praticidade

        )
        
      )
    }



       </ScrollView>

    </SafeAreaView>

</SafeAreaProvider>


);
}

